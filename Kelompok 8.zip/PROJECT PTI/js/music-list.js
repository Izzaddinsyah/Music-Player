let allMusic = [
  
  {
    name: "Viva la Vida-Coldplay",
    artist: "Coldplay",
    img: "Coldplay",
    src: "Coldplay"
  },
  {
    name: "Coloratura-Coldplay",
    artist: "Coldplay",
    img: "coloratura",
    src: "coloratura"
  },
  {
  name: "It Will Rain-Bruno Mars",
  artist: "Bruno Mars",
  img: "Bruno Mars",
  src: "Bruno Mars"
},
  
]